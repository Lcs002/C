#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 30

int  aleatorio (int, int);
void imprimir  (char *);
void rellenar  (char *);
void eliminar  (char *, char);
void compactar (char *);


void main ()
{
    char arr[SIZE], c;
    srand(time(NULL));
    rellenar(arr);
    do
    {
        printf("\n\n\nIntroduzca una letra mayuscula: ");
        scanf("%c", &c);
        fflush(stdin);
    } while (c < 'A' || c > 'F');
    eliminar(arr, c);
    compactar(arr);
}

// ====== FUNCIONES

int aleatorio (int inf, int sup)
{
    int aux = inf;

    if (inf > sup)
    {   inf = sup;
        sup = aux;
    }
    return (rand()%(sup-inf+1)+inf);
}


void imprimir (char * arr)
{
    printf("\n\n");
    int i;
    for (i = 0; i < SIZE - 1; i++)
        printf("%c ", arr[i]);
    printf("\n");
}

void rellenar(char * arr)
{
    int i;
    for (i = 0; i < SIZE - 1; i++)
        arr[i] = aleatorio('A', 'F');
    imprimir(arr);
}

void eliminar (char * arr, char c)
{
    int i;
    for (i = 0; i < SIZE - 1; i++)
        if (arr[i] == c)
            arr[i] = '.';
    imprimir(arr);
}

void compactar(char * arr)
{
    int i, ult; // ult es el ultimo char a la izquierda
    for (i = ult = 0; i < SIZE - 1; i++)
        /* Comprobamos si el char tiene que  ser cambiado de lugar. Para ello, que
        el char actual no sea un blanco y que el ultimo char sea un blanco ('.') */
        if (arr[i] != '.' && arr[ult] == '.')
        {
            arr[ult] = arr[i]; // Movemos el char para la �ltima posici�n
            arr[i] = '.'; // Hacemos que la posici�n anterior sea un blanco
            ult = arr[ult+1] == '.' ? ult+1 : i;/* Si el antiguo ultimo blanco + 1 es un blanco, el ultimo char pasa a ser ult+1
                                                         sino, el ultimo pasa a ser el mismo char */
        }
        /* Comprobamos si el char es un blanco, si lo es, y el ultimo char no es un
        blanco, �l es el ultimo char */
        else if (arr[i] == '.' && arr[ult] != '.')
            ult = i;
    imprimir(arr);
}
