#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct
{
    char id[11];
    unsigned n[6];
} Apuesta;


int random(int, int);
void crear_num(unsigned[6]);
void premiar(int[6], const char*);
unsigned acertados(Apuesta, unsigned[6], unsigned[]);


int main()
{
    Apuesta ap;
    FILE* fapuestas;
    FILE* fpremiados;
    unsigned premiado[6], acc[6];
    char fapuestas_name[20];
    char fpremiados_name[20];
    unsigned i, j;

    srand(time(NULL));

    printf("\nDe donde quieres leer las apuestas? :");
    gets(fapuestas_name);

    printf("\nDonde quieres guardar los premiados? :");
    gets(fpremiados_name);

    if (!(fapuestas=fopen(IN, "rb")))
        exit(1);

    if (!(fpremiados=fopen(OUT, "w")))
        exit(1);

    crear_num(premiado);

    fprintf(fpremiados, "Combinaci�n ganadora: ");
    for (i=0; i<6; i++)
        fprintf(fpremiados, "%u ", premiado[i]);
    fprintf(fpremiados, "\n");

    while (fread(&ap, sizeof(Apuesta), 1, fapuestas))
        if ((j = acertados(ap, premiado, acc)) > 1)
        {
            fprintf(fpremiados, "%s %u: ", ap.id, j);

            for (i = 0; i<6; i++)
                fprintf(fpremiados, "%2u ", ap.n[i]);

            fprintf(fpremiados, "| ");

            for (i = 0; i<j; i++)
                fprintf(fpremiados, "%2u ", acc[i]);

            fprintf(fpremiados, "\n");
        }


    fclose(fpremiados);
    fclose(fapuestas);
    return 0;
}


void crear_num(unsigned _num[6])
{
    int i, j;
    for (i=0; i<6;)
    {
        _num[i] = random(1, 49);
        for (j=0; j<i && _num[j] != _num[i]; j++);
        if (j == i)
            i++;
    }
}

unsigned acertados(Apuesta _ap, unsigned _premiado[6], unsigned * _acertados)
{
    unsigned acertos = 0, i, j;
    for (i=0; i<6; i++)
    {
        for(j=0; j<6 && _ap.n[i] != _premiado[j]; j++);

        if (j<6)
            _acertados[acertos++] = _ap.n[i];
    }
    return acertos;
}

int random(int a, int b)
{
    return (rand()%(b-a+1)+a);
}
