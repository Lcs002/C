#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef enum
{
    FILE_ERROR
}F_ERROR;

typedef struct
{
    char id[11];
    unsigned n[6];
} Apuesta;

int random(int, int);
void crear_id(char [11]);
void crear_num(unsigned [6]);
void crear_apuesta(Apuesta*);
void crear_fapuestas(const char *, unsigned);

int main(void)
{
    char fname[20];
    unsigned ap;


    srand(time(NULL));
    printf("\nDonde quieres guardar las apuestas? :");
    gets(fname);

    printf("\nCuantas apuestas quieres generar? :");
    scanf("%u", &ap);
    fflush(stdin);

    printf("\nEl tama�o del archivo va a ser %.9fmb Seguir? (S/N): ", (sizeof(Apuesta)/1000000.f));
    if (toupper(getchar()) != 'S')
        return 1;

    crear_fapuestas(fname, ap);
    return 0;
}

void crear_fapuestas(const char * _fname, unsigned _ap)
{
    int i;
    FILE* f_in;
    Apuesta ap;

    if (!(f_in=fopen(_fname, "wb")))
        exit(FILE_ERROR);

    for (i=0; i<_ap; i++)
    {
        crear_apuesta(&ap);
        fwrite(&ap, sizeof(Apuesta), 1, f_in);
    }

    fclose(f_in);
}

void crear_id(char _id[11])
{
    int i;
    _id[0] = '2';
    _id[1] = '8';
    for (i=2; i<10; i++)
        _id[i] = random('0', '9');
    _id[10] = random('A', 'Z');
    _id[11] = '\0';
}

void crear_num(unsigned _num[6])
{
    int i, j;
    for (i=0; i<6;)
    {
        _num[i] = random(1, 49);
        for (j=0; j<i && _num[j] != _num[i]; j++);
        if (j == i)
            i++;
    }
}

void crear_apuesta(Apuesta* _ap)
{
    crear_id(_ap->id);
    crear_num(_ap->n);
}

int random(int a, int b)
{
    return (rand()%(b-a+1)+a);
}
