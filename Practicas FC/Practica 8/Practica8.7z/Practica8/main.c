// includes y defines
#include <stdio.h>
#include <stdlib.h>
#define N 200



// estructuras

struct Tfecha {
    int dia, mes, anio;
    };

struct Tcliente {
    char apellidos[40+1];
    struct Tfecha antiguedad;
    float ultimaCompra;
    };

struct TlistaClientes{
	int numClientes;
	struct Tcliente arrayClientes[N];
};


// prototipos
void scanFecha(struct Tfecha *);
void printFecha (struct Tfecha);
void scanCliente (struct Tcliente *);
void printCliente (struct Tcliente);
void printListaClientes (struct TlistaClientes);
void inicializarLista (struct TlistaClientes *);
void anadirCliente (struct TlistaClientes *);
int longitudLista (struct TlistaClientes);



// main
void main()
{
    struct TlistaClientes lst_clientes;
    inicializarLista(&lst_clientes);
    do
    {
        anadirCliente(&lst_clientes);
        fflush(stdin);
        printf("\nanadir otro cliente (s/n)? ");
    } while (getchar() == 's');
    printListaClientes(lst_clientes);
}

// implementacion de las funciones
void scanFecha(struct Tfecha * fecha)
{
    do{
        printf("dia? ");
        scanf("%d", &fecha->dia);
    } while(fecha->dia < 0 || fecha->dia > 31);
    do{
        printf("mes? ");
        scanf("%d", &fecha->mes);
    } while (fecha->mes < 1 || fecha->mes > 12);
    do {
        printf("anio? ");
        scanf("%d", &fecha->anio);
    } while (fecha->anio < 0);
}

void scanCliente(struct Tcliente * cliente)
{
    printf("\napellidos? ");
    scanf("%s", cliente->apellidos); //Arrays no llevan &
    scanFecha(&cliente->antiguedad);
    printf("ultima compra? ");
    scanf("%f", &cliente->ultimaCompra);
}

void printCliente(struct Tcliente cliente)
{
    printf("\n\napellido: %s", cliente.apellidos);
    printf("\nantiguedad: %02d-%02d-%d", cliente.antiguedad.dia, cliente.antiguedad.mes, cliente.antiguedad.anio);
    printf("\nultima compra: %.2f", cliente.ultimaCompra);
}

void printListaClientes(struct TlistaClientes lst_clientes)
{
    int i;
    for (i = 0; i < lst_clientes.numClientes; i++)
        printCliente(lst_clientes.arrayClientes[i]);
    printf("\n\n");
}

void inicializarLista(struct TlistaClientes * lst_clientes)
{
    lst_clientes->numClientes = 0;
}

void anadirCliente (struct TlistaClientes * lst_clientes)
{
    if (lst_clientes->numClientes < N)
    {
        lst_clientes->numClientes++;
        scanCliente(&lst_clientes->arrayClientes[lst_clientes->numClientes - 1]);
    }
}

int longitudLista(struct TlistaClientes lst_clientes)
{
    return lst_clientes.numClientes;
}
