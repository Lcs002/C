#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 8

int aleatorio (int, int);
void rellenar(int [SIZE][SIZE]);
void imprimir(int [SIZE][SIZE]);
void mult(int [SIZE][SIZE], int [SIZE][SIZE]);
void triangularSup(int [SIZE][SIZE]);
void triangularInf(int [SIZE][SIZE]);
void identidad(int [SIZE][SIZE]);


int main()
{
    srand(time(NULL));
    int matA[SIZE][SIZE], matB[SIZE][SIZE];
    //1
    rellenar(matA);
    imprimir(matA);
    printf("\n\n");
    //3
    rellenar(matB);
    imprimir(matB);
    printf("\n\n");
    //5
    mult(matA, matB);
    imprimir(matA);
    printf("\n\n");
    //7
    triangularSup(matA);
    imprimir(matA);
    printf("\n\n");
    //9
    triangularSup(matB);
    imprimir(matB);
    printf("\n\n");
    //11
    mult(matB, matA);
    imprimir(matB);
    printf("\n\n");
    //13
    rellenar(matA);
    triangularInf(matA);
    imprimir(matA);
    printf("\n\n");
    //15
    mult(matB, matA);
    imprimir(matB);
    printf("\n\n");
    //17
    identidad(matB);
    imprimir(matB);
    printf("\n\n");
    //19
    mult(matA, matB);
    imprimir(matA);
    printf("\n\n");
}

int aleatorio (int inf, int sup)
{
    int aux = inf;
    if (inf > sup)
    { inf = sup;
        sup = aux;
    }
    return (rand()%(sup-inf+1)+inf);
}

void rellenar(int mat[SIZE][SIZE])
{
    int i, j;
    for (i = 0; i < SIZE; i++)
        for (j = 0; j < SIZE; j++)
            mat[i][j] = aleatorio(-20, 20);
}

void imprimir(int mat[SIZE][SIZE])
{
    int i, j;
    for (i = 0; i < SIZE; i++)
    {
        printf("\n");
        for (j = 0; j < SIZE; j++)
            printf("%7d ", mat[i][j]);
    }
    printf("\n");
}

void mult(int matA [SIZE][SIZE], int matB [SIZE][SIZE])
{
    int matAux [SIZE][SIZE], i, j, k, sum;
    for (i = 0; i < SIZE ; i++)
        for (j = 0; j < SIZE; j++)
        {
            for (k = sum = 0; k < SIZE; k++)
                sum += matA[i][k] * matB[k][j];
            matAux[i][j] = sum;
        }

    for (i = 0; i < SIZE; i++)
        for (j = 0; j < SIZE; j++)
            matA[i][j] = matAux[i][j];
}

void triangularSup(int mat[SIZE][SIZE])
{
    int i, j;
    for (i = 1; i < SIZE; i++)
        for (j = 0; j < i; j++)
            mat[i][j] = 0;
}

void triangularInf(int mat[SIZE][SIZE])
{
    int i, j;
    for (i = 0; i < SIZE - 1; i++)
        for (j = 0; j < SIZE; j++)
            if (j > i)
                mat[i][j] = 0;
}

void identidad(int mat[SIZE][SIZE])
{
    int i, j;
    for (i = 0; i < SIZE; i++)
        for (j = 0; j < SIZE; j++)
            mat[i][j] = i == j;
}
