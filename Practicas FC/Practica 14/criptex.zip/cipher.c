#include <stdio.h>
#include "cipher.h"

char* cph_crot (unsigned char* c)
{
    *c = ( ( *c & 3 ) << 6 ) | (*c >> 2);
    return c;
}

char* cph_cdesrot (unsigned char* c)
{
    *c = ( ( *c & 192 ) >> 6 ) | (*c << 2);
    return c;
}

char* cph_cinvert ( unsigned char* c, unsigned char byte)
{
    *c ^= byte;
    return c;
}

void cph_fencode (FILE* f_in, FILE* f_out, unsigned char byte)
{
    unsigned char c;
    while((c = fgetc(f_in)) && !feof(f_in))
        fputc(*cph_cinvert(cph_crot(&c), byte), f_out);
}

void cph_fdecode (FILE* f_in, FILE* f_out, unsigned char byte)
{
    unsigned char c;
    while((c = fgetc(f_in)) && !feof(f_in))
        fputc(*cph_cdesrot(cph_cinvert(&c, byte)), f_out);
}
