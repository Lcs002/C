#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cipher.h"

#define OPT_NONE -1
#define OPT_C 0
#define OPT_D 1

#define EXTENSION_DECODE "DECODED"
#define EXTENSION_CODE   "CODED"

#define NAME_CAP    90
#define NAME_NEWCAP 100

int           isByte        (char*);
void          fextension    (char*, char*, char*);
unsigned char cbinToDecimal (char[8]);

int main(int argc, char* argv[])
{
    FILE         *f_in, *f_out;
    int           opt = OPT_NONE;
    unsigned char byteValue;
    char          fnewName[NAME_NEWCAP];

    if (argc != 4)
    {
        printf("\nERROR: Faltan/Sobran argumentos");
        printf("\n       [ Argumentos: -c/-d Byte('0'/'1')/(0-255) Filename ]\n");
        return 1;
    }

    if (!strcmp(argv[1], "-c"))
        opt = OPT_C;
    else if (!strcmp(argv[1], "-d"))
        opt = OPT_D;
    else
    {
        printf("\nERROR: Argumento 1: Opcion no reconocida");
        printf("\n       [ Argumentos: -c/-d Byte('0'/'1')/(0-255) Filename ]\n");
        return 2;
    }

    if (strlen(argv[2]) == 8)
        byteValue = cbinToDecimal(argv[2]);
    else if (atoi(argv[2]) >= 0 && atoi(argv[2]) <= 255)
        byteValue = atoi(argv[2]);
    else
    {
        printf("\nERROR: Argumento 2: Tiene que tener 8 char ('0'/'1') o estar entre 0-255");
        printf("\n       [ Argumentos: -c/-d Byte('0'/'1')/(0-255) Filename ]\n");
        return 3;
    }

    if (!isByte(argv[2]))
    {
        printf("\nERROR: Argumento 2: Tiene que ser compuesto de '0' y '1'");
        printf("\n       [ Argumentos: -c/-d Byte('0'/'1')/(0-255) Filename ]\n");
        return 4;
    }

    if (strlen(argv[3]) > NAME_CAP)
    {
        printf("\nERROR: El nombre del fichero es demasiado grande\n");
        return 5;
    }

    if (!(f_in = fopen(argv[3], "r")))
    {
        printf("\nERROR: No se pudo abrir el archivo %s\n", argv[3]);
        return 5;
    }

    switch (opt)
    {
        case OPT_C:
            fextension(fnewName, argv[3], EXTENSION_CODE);
            if (!(f_out = fopen(fnewName, "w")))
            {
                printf("\nERROR: No se pudo abrir el archivo %s\n", fnewName);
                return 5;
            }
            cph_fencode(f_in, f_out, byteValue);
            break;

        case OPT_D:
            fextension(fnewName, argv[3], EXTENSION_DECODE);
            if (!(f_out = fopen(fnewName, "w")))
            {
                printf("\nERROR: No se pudo abrir el archivo %s\n", fnewName);
                return 5;
            }
            cph_fdecode(f_in, f_out, byteValue);
            break;
    }

    fclose (f_in);
    fclose (f_out);

    return 0;
}

int isByte(char* byte)
{
    for (; *byte && (*byte == '1' || *byte == '0'); byte++)
    return *byte == '1' || *byte == '0';
}

void fextension(char* fnewName, char* fname, char* fextension)
{
    char* i = strchr(fname, '.');
    if (!i)
    {
        strcpy(fnewName, fname);
        strcat(fnewName, ".");
    }
    else
        strncpy(fnewName, fname, i - fname + 1);
    strcat(fnewName, fextension);
}

unsigned char cbinToDecimal(char bits[8])
{
    return 
        (bits[0] == '1') << 7 +
        (bits[1] == '1') << 6 +
        (bits[2] == '1') << 5 +
        (bits[3] == '1') << 4 +
        (bits[4] == '1') << 3 +
        (bits[5] == '1') << 2 +
        (bits[6] == '1') << 1 +
        (bits[7] == '1');
}