#ifndef CIPHER_H
    #define CIPHER_H

    char* cph_crot    (unsigned char*);
    char* cph_cdesrot (unsigned char*);
    char* cph_cinvert (unsigned char*, unsigned char);
    void  cph_fencode (FILE*, FILE*, unsigned char);
    void  cph_fdecode (FILE*, FILE*, unsigned char);

#endif // CIPHER
